#Change Log

##v0.5.2
###Added
- on `click.item.context`, the selected element and element where right click occured are given in second argument as an object

##v0.5.1
###Fixed
- Offset bug on non-static parents. See #1

##v0.5.0
Initial Release
