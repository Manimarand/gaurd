﻿using FluentFTP;
using Newtonsoft.Json;
using Rebex.Net;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Controllers
{
    public class Credentials
    {
         public string hostname { get; set; }
         public string username { get; set; }
         public string password { get; set; }
    }
    public class FolderFiles
    {
        public string FolderName { get; set;}
        public string FileName { get; set; }
        public FolderFiles(string foldername, string filename)
        {
            this.FolderName = foldername;
            this.FileName = filename;
        }
    }
    public class HomeController : Controller
    {
        List<string> folder = new List<string>();
        List<string> files = new List<string>();
        FtpClient client;
        public static string MainDirectory = string.Empty;

        public HomeController()
        {
            client = ConnectFTP(client);
        }
        private string DownloadFile(string filename)
        {
            if (client.FileExists(MainDirectory+"/"+filename))
            {
                client.DownloadFile(Server.MapPath("~/temp/"), filename);
                return "success";
            }
            else
            {
                return "Something went wrong.!";
            }
           
        }
        private string DownloadFolder(string Directory)
        {
            List<string> files = new List<string>();
            List<FolderFiles> Folders_and_Files;
            try
            {
                Folders_and_Files = GetFolders(Directory);
                foreach (var item in Folders_and_Files)
                {
                    if(item.FileName!="")
                    files.Add("/demo/"+item.FileName);
                    
                }

            }
            catch (Exception ee)
            {
                throw;
            }

            if (client.DirectoryExists(Directory))
            {
                client.DownloadFiles(Server.MapPath("~/temp/"),files);

            }
                return "success";
        } 
        private List<FolderFiles> GetFolders(string Directory)
        {
           
            List<FolderFiles> FolderList = new List<FolderFiles>(); 
            MainDirectory += "/"+Directory;           
            if (client.DirectoryExists(MainDirectory)) {
                foreach (FtpListItem item in client.GetListing(MainDirectory))
                {
                    
                    string ext = Path.GetExtension(item.Name);
                    string FileName = string.Empty; string FolderName = string.Empty;
                    if (ext != ""&&ext!=".com"&&ext != ".in")
                    {
                        FileName = item.Name;
                       
                    }
                    else {
                        FolderName = item.Name;
                    }
                    FolderList.Add(new FolderFiles(FolderName, FileName));
                }
            }
            return FolderList;
        }
        private FtpClient ConnectFTP(FtpClient client)
        {
            client = new FtpClient("fourthapetech.com");
            client.Credentials = new NetworkCredential("mano", "Manimaran@123");
            client.Connect();
            return client;
        }
        public JsonResult Index()
        {
            List<FolderFiles> Folders_and_Files;
            try
            {
                Folders_and_Files = GetFolders("");

            }
            catch (Exception ee)
            {
                throw;
            }
            //string ss = JsonConvert.SerializeObject(Folders_and_Files);
            return Json(Folders_and_Files, JsonRequestBehavior.AllowGet);
        }
        public JsonResult SelectFile(string directory)
        {
            List<FolderFiles> Folders_and_Files;
            try
            {
                Folders_and_Files = GetFolders(directory);

            }
            catch (Exception ee)
            {
                throw;
            }
            //string ss = JsonConvert.SerializeObject(Folders_and_Files);
            return Json(Folders_and_Files, JsonRequestBehavior.AllowGet);
        }
    }
}
//if (item.Type == FtpFileSystemObjectType.File)
//{

//    long size = client.GetFileSize(item.FullName);

//}

//DateTime time = client.GetModifiedTime(item.FullName);

//FtpHash hash = client.GetHash(item.FullName);